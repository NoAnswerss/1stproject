Started from scratch again
Made the html file
linked it to the CSS 
added the required font family
added id to header.
added a nav 
created href anchors without actual link
added h3's and p's
added a search bar with a img src pin in a div
asigned specific names to each class
changed id and class to class only .
created a html div for CSS Grid
Added display-flex to Header
Added the required font-family
added grid with linked pictures that have a color changing effect when hovered over and ease-out.
change the pictures format from jpeg to png for better quality .
swapped divs into anchors 
added headings and paragraphs to the page .
removed unrequired hover effects
